﻿namespace Group_2
{
    internal class EmployeeTypeItem
    {
        public employeeType Value { get; set; }
        public string Description { get; set; }
    }
}