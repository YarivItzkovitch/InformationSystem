﻿namespace Group_2
{
    public enum MachineType
    {
        Mixer,
        Conveyor,
        Oven,
        Forklift
    }
}