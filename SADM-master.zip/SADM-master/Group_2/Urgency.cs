﻿namespace Group_2
{
    public enum Urgency
    {
        Urgent,
        Minor
    }
}