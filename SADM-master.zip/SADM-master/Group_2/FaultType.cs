﻿namespace Group_2
{
    public enum FaultType
    {
        Broken,
        Oil,
        Electronic
    }
}