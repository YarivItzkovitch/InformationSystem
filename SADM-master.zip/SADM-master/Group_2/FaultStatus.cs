﻿namespace Group_2
{
    public enum FaultStatus
    {
        Fixed,
        Decommissioned,
        Ongoing


    }
}